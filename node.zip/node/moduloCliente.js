const moduloA = require('./moduloA')
const moduloB = require('./moduloB')

console.log(moduloA)
console.log(moduloA.ola)
console.log(moduloA.bemBindo)
console.log(moduloA.ateLogo)

console.log(moduloB.boaNoite())
console.log(moduloB.bomDia)
console.log(moduloB)