const exportar = require('./exportar')
console.log(exportar)