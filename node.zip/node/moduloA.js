this.ola = 'Fala pessoal'
exports.bemBindo = 'Bem vindo ao node'
module.exports.ateLogo = 'Até o proximo exemplo'