const saudacoes = require('./passandoParametros')('Ana', 'Lucas', 'Joao')

// Parametros nesse caso acima sao passados quando a função é acionada no final 

console.log(saudacoes)